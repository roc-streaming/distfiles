#ifndef UTIL_LINUX_EXEC_SHELL_H
#define UTIL_LINUX_EXEC_SHELL_H

extern void exec_shell(void) __attribute__((__noreturn__));

#endif /* UTIL_LINUX_EXEC_SHELL_H */

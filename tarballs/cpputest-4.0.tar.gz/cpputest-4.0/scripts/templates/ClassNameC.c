#include "ClassName.h"

void ClassName_Create(void)
{
}

void ClassName_Destroy(void)
{
}


